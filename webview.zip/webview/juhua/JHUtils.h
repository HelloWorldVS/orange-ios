//
//  JHUtils.h
//  juhua
//
//  Created by 乔耐 on 15/12/2.
//  Copyright © 2015年 juzi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JHUtils : NSObject

+ (CGFloat)appVersion;

@end
